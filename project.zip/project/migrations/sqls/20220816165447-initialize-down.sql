DROP TABLE tags;
DROP TABLE users;
DROP TABLE user_tags;
DROP TABLE tokens;
